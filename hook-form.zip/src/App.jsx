import React, {useState} from 'react';
import './App.css'
import MyForm from './Components/MyForm';


function App() {

  return(
    <>  
      <MyForm></MyForm>
      
    </>
  )
}

export default App;